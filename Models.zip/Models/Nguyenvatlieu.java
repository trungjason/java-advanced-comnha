﻿public  class Nguyenvatlieu
    {
        private String MaNguyenVatLieu;
        private String TenNguyenVatLieu;
        private double DonGia;
        private String DonVi;
        private String TinhTrang;
        private int SoLuongTonKho;
    }