﻿public  class Hoivien
    {

        private String TenHoiVien;
        private String SoDienThoai;
        private double TongSoTienThanhToan;
        private String Email;
        private String MatKhau;
        private String DiaChi;
        private String QuyenLoi;
    }