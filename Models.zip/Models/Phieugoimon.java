﻿public  class Phieugoimon {
    
    private String MaOrder;
    private String GhiChuMonAn;
    private String MaBanAn;
    private String MaNhanVien;

    @OneToMany(mappedBy = "phieugoimon")
    Set<Chitietgoimon> chitietgoimons;
}