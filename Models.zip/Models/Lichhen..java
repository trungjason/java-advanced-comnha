﻿public  class Lichhen
    {
        private String MaLichHen;
        private String? NhuCau;
        private int SoLuongKhach;
        public TimeSpan ThoiGian;
        private DateTime NgayHen;
        private int? TinhTrang;
        private int MaKhachHang;
        private String? MaNhanVien;
        private String? MaBanAn;
    }