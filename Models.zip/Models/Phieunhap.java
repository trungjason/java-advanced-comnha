﻿public  class Phieunhap{
    private String MaPhieuNhap;
    private DateTime NgayNhapHang;
    private double TongGiaNhap;
    private String GhiChu;
    private String MaNhaCungCap;
    private String MaNhanVien;
}