import javax.persistence.*;
 

@Embeddable
public class Chitietgoimon implements Serializable {
    @Column(name = "MaMonAn")
    private Long studentId;

    @Column(name = "MaOrder")
    private Long courseId;
}