﻿public  class Monan{
    @Id
    @GeneratedValue
    private String MaMonAn;

    private String TenMonAn;

    private double DonGia;

    private String DonVi;

    private String MoTa;

    private String MoTaNgan;

    private String HinhAnh;

    private String MaNhom;

    @OneToMany(mappedBy = "monan")
    Set<Chitietgoimon> chitietgoimons;
}