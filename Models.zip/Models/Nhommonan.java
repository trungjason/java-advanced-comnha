﻿public  class Nhommonan
    {
        private String MaNhom;
        private String TenNhom;
    }