﻿public  class Chitietphieunhap
    {
        private String MaNguyenVatLieu;
        private String MaPhieuNhap;
        private int SoLuongNhap;

        public  Nguyenvatlieu MaNguyenVatLieuNavigation;
        public  Phieunhap MaPhieuNhapNavigation;
    }