﻿public  class Hoadon
    {
        private String MaHoaDon;
        private DateTime ThoiGianThanhToan;
        private double? TongTien;
        private double? ChietKhau;
        private int TinhTrang;
        private int? MaKhachHang;
        private String? MaHoiVien;
        private String? MaNhanVien;
        private String MaOrder;
    }