﻿import javax.persistence.*;
 
@Entity
@Table(name = "banan")
public  class Banan {
    @Id
    @GeneratedValue
    private Long MaBanAn;

    private String TinhTrang;
    
    private int SucChua;
    
    private String GhiChu;
}