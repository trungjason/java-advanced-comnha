﻿public  class Khachhang
    {

        private int MaKhachHang;
        private String SoDienThoai;
        private String TenKhachHang;
        private String? DiaChi;
        private String? Email;
    }