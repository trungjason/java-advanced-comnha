﻿import javax.persistence.*;
 

@Entity
@Table(name = "chitietgoimon")
public class Chitietgoimon  {
    @EmbeddedId
    ChitietgoimonKey id;

    @ManyToOne
    @MapsId("MaMonAn")
    @JoinColumn(name = "MaMonAn")
    Monan monan;


    @ManyToOne
    @MapsId("MaOrder")
    @JoinColumn(name = "MaOrder")
    Phieugoimon phieugoimon;

    private int SoLuongMonAn;
}