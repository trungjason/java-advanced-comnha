﻿public  class Nhacungcap
    {
        
        private String MaNhaCungCap;
        private String MoTaNhaCungCap;
        private String TenNhaCungCap;
        private String DiaChi;
        private String SoDienThoai;
    }