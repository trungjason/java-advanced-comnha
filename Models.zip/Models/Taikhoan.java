﻿public  class Taikhoan {
    private Long id;
    private String TenTaiKhoan;
    private String MatKhau;
    private String MaNhanVien;

}