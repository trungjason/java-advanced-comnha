﻿public  class Nhanvien
    {

        private String MaNhanVien;
        private String TenNhanVien;
        private String SoDienThoai;
        private double Luong;
        private String ChucVu;
        private String DiaChi;
        private String Email;

    }