import org.springframework.data.jpa.repository.JpaRepository;

import models.KhachHang;


public interface KhachHangRepository extends JpaRepository<KhachHang, Long> {
	 
}