import org.springframework.data.jpa.repository.JpaRepository;

import models.BanAn;


public interface BanAnRepository extends JpaRepository<BanAn, Long> {
	 
}