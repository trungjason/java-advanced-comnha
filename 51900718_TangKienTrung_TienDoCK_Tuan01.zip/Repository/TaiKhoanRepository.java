import org.springframework.data.jpa.repository.JpaRepository;

import models.TaiKhoan;

public interface TaiKhoanRepository extends JpaRepository<TaiKhoan, Long> {
	 
}