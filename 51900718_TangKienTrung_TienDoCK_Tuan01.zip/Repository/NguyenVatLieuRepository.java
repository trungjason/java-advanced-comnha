import org.springframework.data.jpa.repository.JpaRepository;

import models.NguyenVatLieu;


public interface NguyenVatLieuRepository extends JpaRepository<NguyenVatLieu, Long> {
	 
}