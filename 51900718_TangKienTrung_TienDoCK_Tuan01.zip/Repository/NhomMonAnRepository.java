import org.springframework.data.jpa.repository.JpaRepository;

import models.NhomMonAn;


public interface NhomMonAnRepository extends JpaRepository<NhomMonAn, Long> {
	 
}