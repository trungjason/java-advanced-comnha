import org.springframework.data.jpa.repository.JpaRepository;

import models.LichHen;


public interface LichHenRepository extends JpaRepository<LichHen, Long> {
	 
}