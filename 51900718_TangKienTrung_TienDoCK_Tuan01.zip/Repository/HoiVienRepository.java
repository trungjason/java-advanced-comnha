import org.springframework.data.jpa.repository.JpaRepository;

import models.HoiVien;


public interface HoiVienRepository extends JpaRepository<HoiVien, Long> {
	 
}