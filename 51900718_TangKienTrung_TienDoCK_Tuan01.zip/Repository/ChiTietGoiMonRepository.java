import org.springframework.data.jpa.repository.JpaRepository;

import models.ChiTietGoiMon;


public interface ChiTietGoiMonRepository extends JpaRepository<ChiTietGoiMon, Long> {
	 
}