import org.springframework.data.jpa.repository.JpaRepository;

import models.ChiTietPhieuNhap;


public interface ChiTietPhieuNhapRepository extends JpaRepository<ChiTietPhieuNhap, Long> {
	 
}