import org.springframework.data.jpa.repository.JpaRepository;

import models.PhieuGoiMon;


public interface PhieuGoiMonRepository extends JpaRepository<PhieuGoiMon, Long> {
	 
}