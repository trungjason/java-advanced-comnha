import org.springframework.data.jpa.repository.JpaRepository;

import models.HoaDon;


public interface HoaDonRepository extends JpaRepository<HoaDon, Long> {
	 
}