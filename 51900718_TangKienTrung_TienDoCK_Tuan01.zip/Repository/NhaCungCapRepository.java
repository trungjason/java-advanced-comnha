import org.springframework.data.jpa.repository.JpaRepository;

import models.NhaCungCap;


public interface NhaCungCapRepository extends JpaRepository<NhaCungCap, Long> {
	 
}