import org.springframework.data.jpa.repository.JpaRepository;

import models.PhieuNhap;


public interface PhieuNhapRepository extends JpaRepository<PhieuNhap, Long> {
	 
}