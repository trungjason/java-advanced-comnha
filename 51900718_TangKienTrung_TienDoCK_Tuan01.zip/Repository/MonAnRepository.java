import org.springframework.data.jpa.repository.JpaRepository;

import models.MonAn;


public interface MonAnRepository extends JpaRepository<MonAn, Long> {
	 
}